{
	//사용자 휴대폰 번호;
	onkeydown : function( e ){

		var t = e.target;
			t.value = t.value
				.replace( /\~/gi, "" ).replace( /\`/gi, "" )
				.replace( /\!/gi, "" ).replace( /\@/gi, "" )
				.replace( /\#/gi, "" ).replace( /\$/gi, "" )
				.replace( /\%/gi, "" ).replace( /\^/gi, "" )
				.replace( /\&/gi, "" ).replace( /\*/gi, "" )
				.replace( /\(/gi, "" ).replace( /\)/gi, "" )
				.replace( /\-/gi, "" ).replace( /\_/gi, "" )
				.replace( /\=/gi, "" ).replace( /\+/gi, "" )
				.replace( /\|/gi, "" ).replace( /\\/gi, "" )
				.replace( /[a-z]/gi, "" )
				.replace( /[ㄱ-ㅎ]/gi, "" )
				.replace( /[ㅏ-ㅣ]/gi, "" )
				;
	}
}