{
	//시간 선택시 작동 이벤트;
	onchange : function( e ){
		var t = e.target;

		var val = Number( t.value );

		var price = val * window.__CONFIG[ "시간당 금액" ];

		var target = window.__CONFIG.ELS[ "ID-SPAN-결제금액" ];
			target.innerText = price.toLocaleString() + "원";

		window.__UTIL[ "갱신--ID-SPAN-자동만료일" ]();
	}
}