{
	//사용자 조회 버튼;
	onclick : function( e ){

		var t_phone = window.__CONFIG.ELS[ "ID-INPUT-사용자-휴대폰번호" ];
		var phone = t_phone.value;
		if( phone == "" ){
			alert( "사용자 휴대폰 번호 입력 필요" );
			return;
		}

		//--------------------------------------------------;

		//서버 - '결제요청' 전송;
		var HOST = window.__CONFIG[ "서버호스트(API)" ];

		var resTxt = SUtilXMLHttpReqGet.reqSyncReturn( HOST + "사용자-체크인아웃/index--evt--ID-INPUT-BUTTON-사용자조회"
			+ "?phone=" + phone
		).responseText;

		if( resTxt != "false" ){

			var d = JSON.parse( resTxt );

			window.__CONFIG.ELS[ "ID-TD-사용자-이름" ].innerText = d.name;
			window.__CONFIG.ELS[ "ID-SPAN-결제금액" ].innerText = Number( d.price ).toLocaleString() + "원";
			window.__CONFIG.ELS[ "ID-SPAN-상태" ].innerText = d.status;
			window.__CONFIG.ELS[ "ID-SPAN-자동만료일" ].innerText = window.__UTIL[ "일시--문자열0" ]( new Date( d.timeExpired ) );

			var t = window.__CONFIG.ELS[ "ID-TABLE-사용자정보" ];
				t.style.display = "";
		}
	}
}