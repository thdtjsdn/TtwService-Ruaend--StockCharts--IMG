{
	//사용 종료 버튼;
	onclick : function( e ){

		var t_price = window.__CONFIG.ELS[ "ID-SPAN-결제금액" ];
		if( t_price == "" ){
			alert( "구매 시간 선택 필요" );
			return;
		}

		var timeUse = Number( window.__CONFIG.ELS["ID-SELECT-사용시간"].value );
		var price = t_price.innerText.replace( /\,/gi, "" ).replace( "원", "" );

		var t_phone = window.__CONFIG.ELS[ "ID-INPUT-사용자-휴대폰번호" ];
		var phone = t_phone.value;
		if( phone == "" ){
			alert( "사용자 휴대폰 번호 입력 필요" );
			return;
		}

		var t_name = window.__CONFIG.ELS[ "ID-INPUT-사용자-이름" ];
		var name = t_name.value;
		if( name == "" ){
			alert( "사용자 이름 입력 필요" );
			return;
		}



		//--------------------------------------------------;

		var t = window.__CONFIG.ELS[ "ID-DIV-결제요청후화면" ];
			t.style.display = "";

		//--------------------------------------------------;

		//서버 - '결제요청' 전송;
		var HOST = window.__CONFIG[ "서버호스트(API)" ];

		var resTxt = SUtilXMLHttpReqGet.reqSyncReturn( HOST + "index--evt--ID-INPUT-BUTTON-결제요청"
			+ "?phone=" + phone
			+ "&name=" + name
			+ "&price=" + price

			+ "&timeUse=" + timeUse
			+ "&timeRequest=" + Number( new Date().getTime() )

		).responseText;
	}
}