{
	//관리자-사용자관리 - 사용자 목록에서 입금확인 버튼 클릭;
	onclick : function( e ){

		var t = e.target;
		if( t.tagName == "BUTTON" ){

			if( t.innerText == "입금 확인" ){

				var td = t.parentElement;
				var tr = td.parentElement;
				if( tr.tagName != "TR" ) return;

				var td_phone = tr.children[ 1 ];
				var td_status = tr.children[ 3 ];
				var td_paymentApproval = tr.children[ 7 ];

				var phone = td_phone.innerText;
				console.log( phone );

				//--------------------------------------------------;

				//서버 - '입금 확인' 전송;
				var HOST = window.__CONFIG[ "서버호스트(API)" ];

				var resTxt = SUtilXMLHttpReqGet.reqSyncReturn( HOST + "관리자-사용자관리/index--evt--ID-TBODY-사용자목록"
					+ "?phone=" + phone
				).responseText;

				if( resTxt != "false" ){
					var d = JSON.parse( resTxt );

					td_status.innerText = d.status;

					window.__UTIL[ "관리자-사용자관리/사용자목록/상태-배경색지정" ]( td_status );

					td_paymentApproval.innerHTML = window.__UTIL[ "일시--문자열0" ]( new Date( Number( d.timePaymentApproval ) ) ).replace( "일 ", "일<br>" );
				}
			}
		}
	}
}